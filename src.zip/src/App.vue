<template>
  <div id="app">
    <input type="text" placeholder="请输入用户名" name="uName" v-model="uName"><br><br>
    <input type="text" placeholder="请输入密码" name="uPwd" v-model="uPwd"><br><br>
    <button @click="reg">注册</button>
  </div>
</template>

<script>

export default {
  data(){
     return{
        uName:"",
        uPwd:"",
     }
  },
  methods:{
     reg(){
        let uName = this.uName
        let uPwd = this.uPwd
        let url  = "http://localhost:8888/vue/dome/Api/test.php?uName="+uName+"&uPwd="+uPwd;
        this.$axios.get(url).then((res)=>{
            if(res.data.msg == 'ok'){
                localStorage['uToken'] = res.data.uToken
                this.$router.push('/')
            }
        })

     }
  }
}
</script>

<style>

</style>
