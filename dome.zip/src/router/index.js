import Vue from 'vue'
import Router from 'vue-router'
import Reg from '../reg/index'
import Main from '../main/index'
import Login from '../login/index'

Vue.use(Router)

export default new Router({
	routes:[
		{
			path:'/',
			component:Login,
        },
		{
			path:'/reg',
			component:Reg,
        },
        {
			path:'/main',
			component:Main,
		}
	]
})