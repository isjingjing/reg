<template>
  <div class="Home">
      <div class="box">
            <p> <span>用户名:</span> <input type="text" v-model="uName"></p>
            <p> <span>密码:</span><input type="text" v-model="uPwd"></p>
            <p> 
                <button @click="deng">登陆</button>
                <button @click="zhu">注册</button>
            </p>
            <p>  </p>
      </div>
      
  </div>
</template>

<script>
export default {
    data(){
        return{
            uName:"",
            uPwd:""
        }
    },
    methods:{
        zhu(){
            this.$router.push('/reg')
        },
        deng(){
                let uName=this.uName
                let uPwd=this.uPwd
                let url="http://localhost:8888/vue/dome/Api/login.php?uName="+uName+"&uPwd="+uPwd+"&uToken="+localStorage["uToken"];
                this.$axios.get(url).then((res)=>{
                    console.log(res.data)
                    if(res.data.msg=="loginOk"){
                        alert("登录成功")
                           this.$router.push("/main")
                    }else{
                        alert("登录失败")
                    }
                })

        }
    }
}
</script>

<style>
.Home{
    width: 100%;
    height: 100%;
    background:url('/1111.jpg');
    background-size:100% 100%; 
}
.box{
    width: 300px;
    height: 300px;
    /* background: pink; */
    position: fixed;
    right: 20%;
    top: 20%;
}
.box p{
    width: 100%;
    height: 50px;
    padding: 10px;
    box-sizing: border-box;
    color: #ffff;

}
.box p input{
    width: 80%;
    height: 100%;
    background: #ffff;
    border-radius: 15px;
    border: none;
    padding-left: 10px;
    box-sizing: border-box;
    
}
.box p span{
    width: 20%;
    display: inline-block;
    height: 100%;
}
.box p button{
    width: 40%;
    height: 100%;
    border: none;
    margin-left: 22px;
    border-radius: 5px;
}

</style>
