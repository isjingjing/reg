<?php
   header('Access-Control-Allow-Origin:*');
   include("conn.php");
 
   $uPwd = $_GET["uPwd"];
   $uName = $_GET["uName"];
   $uToken = base64_encode(time());

   $sql = "insert into user(uName,uPwd,uToken) values('{$uName}','{$uPwd}','{$uToken}')";
   if(mysql_query($sql)){
      $arr = array("msg"=>"ok","uToken"=>$uToken);
      echo json_encode($arr);
   }else{
      $arr = array("msg"=>"no");
      echo json_encode($arr);
   }

   
?>